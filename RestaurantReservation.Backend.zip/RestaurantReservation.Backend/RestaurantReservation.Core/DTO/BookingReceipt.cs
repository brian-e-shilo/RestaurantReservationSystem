﻿namespace RestaurantReservation.Core.DTO
{
    public class BookingReceipt
    {
        public string Email { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
    }
}
