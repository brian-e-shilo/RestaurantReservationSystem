﻿namespace RestaurantReservation.Infrastructure.Data
{
    public interface IDbInitializer
    {
        void Initialize();
    }
}
