﻿namespace RestaurantReservation.Infrastructure.Data
{
    public interface IPromotionEmail
    {
        void CheckSentStatus();
    }
}
